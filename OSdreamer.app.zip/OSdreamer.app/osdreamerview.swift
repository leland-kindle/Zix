import SwiftUI

struct OSDreamerView: View {
    @State private var osDescription: String = ""
    @State private var aiResponse: String = ""
    @State private var isLoading: Bool = false
    @State private var availableISOs: [String] = [
        "Ubuntu 24.04 x86-64 (Example)",
        "Fedora 40 ARM64 (Example)",
        "Windows 11 Evaluation (Example)",
        "macOS Sonoma Beta (Example - Requires Specific Hardware/Entitlements)"
    ]
    @State private var selectedISO: String?

    var body: some View {
        VStack {
            Text("OSDreamer")
                .font(.largeTitle)
                .padding()

            TextEditor(text: $osDescription)
                .frame(height: 150)
                .border(Color.gray)
                .padding()
                .textInputAutocapitalization(.never)
                .disableAutocorrection(true)

            Button("Dream an OS") {
                dreamOS()
            }
            .padding()
            .disabled(isLoading || osDescription.isEmpty)

            if isLoading {
                ProgressView("Dreaming...")
                    .padding()
            }

            Text("AI Response:")
                .font(.headline)
                .padding(.top)

            ScrollView {
                Text(aiResponse)
                    .font(.body)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(height: 150)
            .border(Color.gray)
            .padding()

            if !availableISOs.isEmpty {
                Picker("Available ISOs", selection: $selectedISO) {
                    Text("Select an ISO").tag(nil as String?)
                    ForEach(availableISOs, id: \.self) { iso in
                        Text(iso).tag(iso as String?)
                    }
                }
                .padding()

                Button("Run in VirtualForge") {
                    runInVirtualForge()
                }
                .padding()
                .disabled(selectedISO == nil)
            }

            Spacer()
        }
        .padding()
    }

    func dreamOS() {
        isLoading = true
        aiResponse = "Simulating AI analysis of your description..."

        // Simulate AI suggesting ISOs based on the description (hardcoded for now)
        DispatchQueue.global(qos: .userInitiated).asyncAfter(deadline: .now() + 2) {
            let description = osDescription.lowercased()
            var suggestions: [String] = []

            if description.contains("linux") && description.contains("lightweight") {
                suggestions.append("Alpine Linux (Example)")
            } else if description.contains("windows") && description.contains("latest") {
                suggestions.append("Windows 11 Insider Preview (Example)")
            } else if description.contains("macos") && description.contains("arm") {
                suggestions.append("macOS Ventura ARM64 Developer Beta (Example - Requires Specific Hardware)")
            } else {
                suggestions.append(contentsOf: availableISOs) // Default suggestions
            }

            DispatchQueue.main.async {
                aiResponse = "Based on your description, here are some potential operating systems you might consider:"
                availableISOs = suggestions.removingDuplicates() // Ensure no duplicates
                isLoading = false
            }
        }
    }

    func runInVirtualForge() {
        guard let selectedISO = selectedISO else { return }
        // Logic to launch VirtualForge and attempt to run the selected ISO
        print("Attempting to run '\(selectedISO)' in VirtualForge (Simulated).")
        // In a real scenario, you would need to handle:
        // 1. Checking if VirtualForge is installed.
        // 2. Potentially constructing a command-line command or using a deep link to open VirtualForge
        //    and pre-configure a new VM with a placeholder path for the selected ISO.
        // 3. Guiding the user to select the actual ISO file within VirtualForge.

        aiResponse += "\n\nAttempting to launch VirtualForge with a pre-configured VM for '\(selectedISO)'. You may need to manually select the ISO file within VirtualForge."
    }
}

extension Array where Element: Hashable {
    func removingDuplicates() -> [Element] {
        var addedDict = [Element: Bool]()
        return filter {
            addedDict.updateValue(true, forKey: $0) == nil
        }
    }
}
