import SwiftUI

@main
struct OSDreamerApp: App {
    var body: some Scene {
        WindowGroup {
            OSDreamerView()
        }
    }
}
