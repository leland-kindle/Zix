import SwiftUI

@main
struct StreamVerseApp: App {
    @StateObject var themeManager = ThemeManager.shared
    @StateObject var authenticationManager = AuthenticationManager()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(themeManager)
                .environmentObject(authenticationManager)
        }
    }
}
