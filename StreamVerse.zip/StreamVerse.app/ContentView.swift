import SwiftUI

struct ContentView: View {
    @EnvironmentObject var themeManager: ThemeManager
    @EnvironmentObject var authenticationManager: AuthenticationManager
    @State private var showingSettings = false
    @State private var showingCreateContent = false
    @State private var showingLiveStream = false
    @State private var showingPublish = false

    var body: some View {
        NavigationView {
            VStack {
                Text("StreamVerse")
                    .font(.largeTitle)
                    .padding(.bottom, 50)
                    .foregroundColor(themeManager.currentPrimaryColor)

                Button("Create") {
                    showingCreateContent = true
                }
                .padding()
                .buttonStyle(.borderedProminent)
                .tint(themeManager.currentPrimaryColor)
                .sheet(isPresented: $showingCreateContent) {
                    CreateContentView()
                }

                Button("Go Live") {
                    showingLiveStream = true
                }
                .padding()
                .buttonStyle(.borderedProminent)
                .tint(themeManager.currentPrimaryColor)
                .sheet(isPresented: $showingLiveStream) {
                    LiveStreamView()
                }

                Button("Publish") {
                    showingPublish = true
                }
                .padding()
                .buttonStyle(.borderedProminent)
                .tint(themeManager.currentPrimaryColor)
                .sheet(isPresented: $showingPublish) {
                    PublishView()
                }
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showingSettings = true
                    } label: {
                        Image(systemName: "gear")
                            .foregroundColor(themeManager.currentPrimaryColor)
                    }
                    .sheet(isPresented: $showingSettings) {
                        SettingsView()
                    }
                }
            }
            .navigationTitle("Home")
        }
    }
}
