import SwiftUI
import AVFoundation

struct LiveStreamView: View {
    @Environment(\.dismiss) var dismiss
    @State private var isLive: Bool = false
    @State private var audioSession: AVAudioSession?
    @State private var audioRecorder: AVAudioRecorder?
    @State private var outputFileName: String = "live_stream"
    @State private var selectedAudioOption: AudioOption = .both
    @State private var fileExtension: String = "mp4"

    enum AudioOption: String, CaseIterable, Identifiable {
        case both = "Both"
        case internalOnly = "Internal Only"
        case externalOnly = "External Only"
        case none = "None"

        var id: Self { self }
    }

    var body: some View {
        NavigationView {
            VStack {
                Text("Live Stream")
                    .font(.largeTitle)
                    .padding()

                Picker("Audio Source", selection: $selectedAudioOption) {
                    ForEach(AudioOption.allCases) { option in
                        Text(option.rawValue).tag(option)
                    }
                }
                .padding()

                HStack {
                    TextField("Output File Name", text: $outputFileName)
                    Text(".\(fileExtension)")
                }
                .padding()

                Picker("File Extension", selection: $fileExtension) {
                    Text("mp4").tag("mp4")
                    Text("mov").tag("mov")
                    Text("app").tag("app") // Note: Actual .app creation is complex
                    Text("pkg").tag("pkg") // Note: Actual .pkg creation is complex
                    Text("iso").tag("iso") // Note: Actual .iso creation is complex
                    Text("other...").tag("other") // Placeholder for more options
                }
                .padding()

                Button(action: {
                    if isLive {
                        stopLiveStream()
                    } else {
                        startLiveStream()
                    }
                    isLive.toggle()
                }) {
                    Text(isLive ? "Stop Live Stream" : "Start Live Stream")
                        .padding()
                        .background(isLive ? Color.red : Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                .padding()
            }
            .onAppear(perform: setupAudioSession)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
            .navigationTitle("Go Live")
        }
    }

    func setupAudioSession() {
        do {
            audioSession = AVAudioSession.sharedInstance()
            try audioSession?.setCategory(.playAndRecord, mode: .default, options: [.mixWithOthers, .allowBluetoothA2DP])
            try audioSession?.setActive(true)

            let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let fileURL = documentsDirectory.appendingPathComponent("\(outputFileName).\(fileExtension)")

            let settings: [String : Any] = [
                AVFormatIDKey: kAudioFormatMPEG4AAC,
                AVSampleRateKey: 44100.0,
                AVNumberOfChannelsKey: 2,
                AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
            ]

            audioRecorder = try AVAudioRecorder(url: fileURL, settings: settings)
            audioRecorder?.prepareToRecord()

        } catch {
            print("Error setting up audio session: \(error.localizedDescription)")
        }
    }

    func startLiveStream() {
        audioRecorder?.record()
        print("Live stream started.")
        // Implement video recording using AVFoundation or other frameworks
    }

    func stopLiveStream() {
        audioRecorder?.stop()
        print("Live stream stopped. Saved to: \(audioRecorder?.url?.path ?? "")")
        // Implement saving of the video recording
    }
}
