import SwiftUI

struct CreateContentView: View {
    @Environment(\.dismiss) var dismiss
    @State private var creatingTVShow = false
    @State private var creatingMovie = false

    var body: some View {
        NavigationView {
            VStack {
                Text("Create New Content")
                    .font(.title2)
                    .padding(.bottom, 30)

                Button("Create TV Show") {
                    creatingTVShow = true
                }
                .padding()
                .buttonStyle(.borderedProminent)
                .sheet(isPresented: $creatingTVShow) {
                    ProjectDetailView(contentType: .tvShow)
                }

                Button("Create Movie") {
                    creatingMovie = true
                }
                .padding()
                .buttonStyle(.borderedProminent)
                .sheet(isPresented: $creatingMovie) {
                    ProjectDetailView(contentType: .movie)
                }
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
            .navigationTitle("Create")
        }
    }
}
