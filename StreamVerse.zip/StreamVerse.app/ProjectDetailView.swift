import SwiftUI

enum ContentType {
    case tvShow, movie
}

struct ProjectDetailView: View {
    @Environment(\.dismiss) var dismiss
    let contentType: ContentType
    @State private var projectName: String = ""
    // Add more project details and collaboration UI here

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Project Information")) {
                    TextField("Project Name", text: $projectName)
                    Text("Creating a \(contentType == .tvShow ? "TV Show" : "Movie")")
                }

                Section(header: Text("Collaboration (Placeholder)")) {
                    Text("Collaboration features will go here.")
                    // Add UI for inviting collaborators
                }

                Button("Save Project") {
                    saveProject()
                    dismiss()
                }
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
            .navigationTitle(projectName.isEmpty ? "New Project" : projectName)
        }
    }

    func saveProject() {
        print("Saving project: \(projectName) as \(contentType)")
        // Implement actual project saving logic
    }
}
