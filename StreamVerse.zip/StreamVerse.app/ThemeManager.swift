import SwiftUI

struct Theme: Identifiable {
    let id = UUID()
    let name: String
    let primaryColor: Color
    let secondaryColor: Color
    // ... other theme properties
}

class ThemeManager: ObservableObject {
    static let shared = ThemeManager()
    @AppStorage("selectedThemes") var selectedThemeNames: [String] = ["Default"]
    @AppStorage("isRainbowBlendEnabled") var isRainbowBlendEnabled: Bool = false

    let themes: [Theme] = [
        Theme(name: "Default", primaryColor: .blue, secondaryColor: .gray),
        Theme(name: "Netflix", primaryColor: Color(red: 0.8, green: 0.1, blue: 0.1), secondaryColor: .black),
        Theme(name: "Hulu", primaryColor: Color(red: 0.1, green: 0.6, blue: 0.3), secondaryColor: .white),
        Theme(name: "Disney+", primaryColor: Color(red: 0.1, green: 0.3, blue: 0.7), secondaryColor: .white),
        // ... more themes
    ]

    var currentPrimaryColor: Color {
        if isRainbowBlendEnabled {
            return Color.random() // Placeholder for rainbow blend logic
        } else if let selectedTheme = themes.first(where: { $0.name == selectedThemeNames.first }) {
            return selectedTheme.primaryColor
        } else {
            return themes.first!.primaryColor // Default
        }
    }

    // ... similar logic for other color properties if needed
}

extension Color {
    static func random() -> Color {
        return Color(
            red: Double.random(in: 0...1),
            green: Double.random(in: 0...1),
            blue: Double.random(in: 0...1)
        )
    }
}
