import SwiftUI
import SceneKit

struct ContentView: View {
    @StateObject var gameManager = GameManager()

    var body: some View {
        ZStack {
            Renderer(gameManager: gameManager)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            UserInterfaceView(gameManager: gameManager) // Your UI overlay
        }
    }
}

// Make sure your GameManager class in GameManager.swift:
// 1. Creates and holds an SCNScene (e.g., as a @Published property).
// 2. Creates and holds a camera node (e.g., as a @Published property).
// 3. Conforms to the SCNSceneRendererDelegate protocol and implements the
//    renderer(_:updateAtTime:) method for your game loop logic.
