import SwiftUI
import SceneKit
import Combine

class GameManager: NSObject, ObservableObject, SCNSceneRendererDelegate {
    @Published var playerHealth: Int = 100
    @Published var playerSanity: Int = 100
    @Published var showCrafting: Bool = false
    @Published var useSimplified2D: Bool = false // Toggle for complexity

    let scene = SCNScene()
    let cameraNode = SCNNode()
    let playerNode = SCNNode()
    var worldData: [String: String] = ["forest": "dark and dense", "town": "eerie and quiet"] // Simplified world
    var currentArea: String = "forest"
    var inventory: [String: Int] = ["wood": 10, "stone": 5]
    var mysteryProgress: Int = 0

    override init() {
        super.init()
        setupScene()
    }

    func setupScene() {
        cameraNode.camera = SCNCamera()
        cameraNode.position = SCNVector3(x: 0, y: 5, z: 10)
        scene.rootNode.addChildNode(cameraNode)

        playerNode.geometry = SCNSphere(radius: 0.5)
        playerNode.position = SCNVector3Zero
        scene.rootNode.addChildNode(playerNode)

        let ambientLightNode = SCNNode()
        ambientLightNode.light = SCNLight()
        ambientLightNode.light?.type = .ambient
        ambientLightNode.light?.intensity = 500
        scene.rootNode.addChildNode(ambientLightNode)
    }

    func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        // Basic "AI" for a single creature (very simple)
        if let creatureNode = scene.rootNode.childNode(withName: "creature", recursively: true) {
            let playerDirection = SCNVector3(playerNode.position.x - creatureNode.position.x, 0, playerNode.position.z - creatureNode.position.z)
            let distance = sqrt(playerDirection.x * playerDirection.x + playerDirection.z * playerDirection.z)
            if distance < 5 {
                creatureNode.look(at: playerNode.position)
                let moveDirection = SCNVector3(playerDirection.x / distance * 0.01, 0, playerDirection.z / distance * 0.01)
                creatureNode.position = SCNVector3(creatureNode.position.x + moveDirection.x, creatureNode.position.y, creatureNode.position.z + moveDirection.z)
            }
        }
        // Simulate sanity decrease over time or in certain areas
        if Int.random(in: 0...100) == 0 {
            playerSanity = max(0, playerSanity - 1)
        }
    }

    func movePlayer(direction: SCNVector3) {
        let move = SCNAction.move(by: direction, duration: 0.1)
        playerNode.runAction(move)
    }

    func playerInteract() {
        print("Player interacts with the environment in \(currentArea)")
        // Basic mystery progression based on area
        if currentArea == "town" && mysteryProgress == 0 {
            print("Found a strange note in the town square.")
            inventory["note"] = 1
            mysteryProgress += 1
        } else if currentArea == "forest" && inventory["note"] != nil && mysteryProgress == 1 {
            print("The note leads to a hidden clearing...")
            // Spawn a simple creature (for demonstration)
            let creatureNode = SCNSphere(radius: 0.7)
            creatureNode.name = "creature"
            creatureNode.position = SCNVector3(x: 5, y: 0.7, z: -5)
            scene.rootNode.addChildNode(creatureNode)
            mysteryProgress += 1
        } else if currentArea == "forest" && mysteryProgress == 2 {
            print("The creature seems hostile!")
            // (In a real game, you'd handle combat)
        }
    }

    func craftItem(item: String) {
        if item == "simple_tool" && inventory["wood"] ?? 0 >= 3 && inventory["stone"] ?? 0 >= 1 {
            inventory["wood"]! -= 3
            inventory["stone"]! -= 1
            inventory["simple_tool"] = (inventory["simple_tool"] ?? 0) + 1
            print("Crafted a simple tool.")
        } else {
            print("Not enough resources to craft \(item).")
        }
    }

    // ... more survival mechanics (hunger, thirst), area transitions, etc.
}
