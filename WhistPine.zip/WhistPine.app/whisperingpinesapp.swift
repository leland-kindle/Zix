import SwiftUI
import SceneKit // Keeping SceneKit for basic 3D possibility

@main
struct WhisperingPinesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    @StateObject var gameManager = GameManager()

    var body: some View {
        ZStack {
            if gameManager.useSimplified2D {
                // Placeholder for a simplified 2D SpriteKit or Canvas view
                Text("Simplified 2D World (Conceptual)")
            } else {
                GameSceneView(gameManager: gameManager)
            }
            UserInterfaceView(gameManager: gameManager)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct GameSceneView: NSViewRepresentable {
    @ObservedObject var gameManager: GameManager

    func makeNSView(context: Context) -> SCNView {
        let sceneView = SCNView()
        sceneView.scene = gameManager.scene
        sceneView.delegate = gameManager
        sceneView.pointOfView = gameManager.cameraNode
        sceneView.backgroundColor = .black
        return sceneView
    }

    func updateNSView(_ nsView: SCNView, context: Context) {
        // Updates if needed
    }
}

struct UserInterfaceView: View {
    @ObservedObject var gameManager: GameManager

    var body: some View {
        VStack {
            HStack {
                Text("Health: \(gameManager.playerHealth)")
                Spacer()
                Text("Sanity: \(gameManager.playerSanity)")
            }
            .padding()
            Spacer()
            HStack {
                Button("Interact") { gameManager.playerInteract() }
                Spacer()
                Button("Craft") { gameManager.showCrafting = true }
            }
            .padding()
        }
        .sheet(isPresented: $gameManager.showCrafting) {
            Text("Crafting Menu (Conceptual)")
        }
    }
}
