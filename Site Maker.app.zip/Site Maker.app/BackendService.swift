import Foundation

enum BackendError: Error {
    case saveFailed
    case emailCreationFailed
    // ... more errors
}

class BackendService {
    static let shared = BackendService()

    func saveWebsite(website: Website, completion: @escaping (Result<URL, Error>) -> Void) {
        // Simulate saving to a backend and generating a URL
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            let freeURL = URL(string: "https://\(website.name.replacingOccurrences(of: " ", with: "").lowercased()).sitemaker.com")!
            completion(.success(freeURL))
        }
    }

    func createEmailAccount(emailPrefix: String, companyName: String, numberOfEmails: Int, websiteID: UUID, completion: @escaping (Result<[EmailAccount], Error>) -> Void) {
        // Simulate creating email accounts
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            var emails: [EmailAccount] = []
            let domain = "\(companyName.replacingOccurrences(of: " ", with: "").lowercased()).sitemaker.com"
            for i in 0..<numberOfEmails
