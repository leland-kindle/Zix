import SwiftUI

struct CodeEditorView: View {
    @Binding var code: String
    @Environment(\.dismiss) var dismiss

    var body: some View {
        NavigationView {
            TextEditor(text: $code)
                .font(.system(size: 14, design: .monospaced))
                .lineSpacing(2)
                .padding()
            .navigationTitle("Code Editor")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}
