import SwiftUI

struct AIAssistantView: View {
    @Binding var websiteContent: String
    @State private var prompt: String = ""
    @State private var response: String = ""
    @Environment(\.dismiss) var dismiss

    var body: some View {
        NavigationView {
            VStack {
                TextEditor(text: $prompt)
                    .frame(height: 150)
                    .border(Color.gray)
                    .padding()
                    .overlay(alignment: .topLeading) {
                        if prompt.isEmpty {
                            Text("Ask the AI to modify your website...")
                                .foregroundColor(.gray)
                                .padding(EdgeInsets(top: 8, leading: 12, bottom: 0, trailing: 0))
                        }
                    }

                Button("Ask AI") {
                    askAI()
                }
                .padding()

                ScrollView {
                    Text(response)
                        .padding()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .border(Color.gray)
                .padding()
            }
            .navigationTitle("AI Assistant")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        updateWebsite()
                        dismiss()
                    }
                }
            }
        }
    }

    func askAI() {
        print("AI Prompt: \(prompt)")
        // Call BackendService to send prompt and get AI response
        response = "AI is processing your request: \(prompt)\n(Response will appear here - this is a placeholder)"
        // In a real implementation, you would send the prompt and websiteContent to an AI model
        // and update the response with the AI's suggestion.
    }

    func updateWebsite() {
        // This is a placeholder. In a real implementation, you would parse the AI response
        // and update the websiteContent accordingly.
        if response.contains("add a button") {
            websiteContent += "<button>Click Me!</button>"
        } else if response.contains("change the background color to green") {
            websiteContent += "<style>body { background-color: green; }</style>"
        }
    }
}
