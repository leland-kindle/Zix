import SwiftUI

struct EmailSetupView: View {
    @Binding var isPresented: Bool
    @Binding var website: Website?
    @State private var emailPrefix: String = ""
    @State private var companyName: String = ""
    @State private var numberOfEmails: Int = 1
    @State private var shouldCustomize = false

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Email Address Setup")) {
                    TextField("Desired Email Prefix", text: $emailPrefix)
                    if !companyName.isEmpty {
                        Text("@\(companyName.replacingOccurrences(of: " ", with: "").lowercased()).sitemaker.com")
                            .foregroundColor(.gray)
                    } else {
                        Text("@yourdomain.sitemaker.com (will be based on website name)")
                            .foregroundColor(.gray)
                    }
                }

                Section(header: Text("Website Details")) {
                    TextField("Company / Website Name", text: $companyName)
                }

                Section(header: Text("Number of Email Addresses")) {
                    Stepper("\(numberOfEmails)", value: $numberOfEmails, in: 1...5) // Example limit
                }

                Button("Continue to Customization") {
                    if let template = website {
                        website = Website(name: companyName, htmlContent: template.baseHTML, cssContent: template.baseCSS, jsContent: template.baseJS)
                        associateEmail()
                        shouldCustomize = true
                    }
                }
                .disabled(emailPrefix.isEmpty || companyName.isEmpty || website == nil)

            }
            .navigationTitle("Set Up Your Free Email")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Back") {
                        // Handle going back
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Skip") {
                        shouldCustomize = true
                        // Proceed to customization without email
                    }
                }
            }
            .navigationDestination(isPresented: $shouldCustomize) {
                if let website = website {
                    WebsiteCustomizerView(website: Binding(get: { website }, set: { self.website = $0 }))
                } else {
                    Text("Error: No website to customize.")
                }
            }
        }
    }

    func associateEmail() {
        if let websiteID = website?.id {
            print("Requesting \(numberOfEmails) email(s) for \(emailPrefix)@\(companyName.replacingOccurrences(of: " ", with: "").lowercased()).sitemaker.com for website ID: \(websiteID)")
            // Call BackendService to create email(s) and associate with the website
        }
    }
}
