import SwiftUI

struct TemplateLibraryView: View {
    @Binding var isPresented: Bool
    @Binding var selectedTemplate: Template?
    @State private var templates: [Template] = [
        Template(name: "Business Basic", description: "A simple template for small businesses.", previewImageURL: URL(string: "https://via.placeholder.com/300/0000FF/808080?Text=Business"), baseHTML: "<h1>Welcome to our business!</h1>", baseCSS: "h1 { color: blue; }", baseJS: ""),
        Template(name: "Personal Portfolio", description: "Showcase your skills and projects.", previewImageURL: URL(string: "https://via.placeholder.com/300/FF0000/FFFFFF?Text=Portfolio"), baseHTML: "<p>My awesome portfolio.</p>", baseCSS: "p { font-size: 16px; }", baseJS: ""),
        // ... more templates
    ]

    var body: some View {
        NavigationView {
            ScrollView {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 200))], spacing: 20) {
                    ForEach(templates) { template in
                        VStack(alignment: .leading) {
                            AsyncImage(url: template.previewImageURL) { image in
                                image.resizable()
                                     .scaledToFit()
                                     .cornerRadius(8)
                            } placeholder: {
                                ProgressView()
                            }
                            Text(template.name)
                                .font(.headline)
                            Text(template.description)
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        .padding()
                        .background(Color.secondary.opacity(0.1))
                        .cornerRadius(10)
                        .onTapGesture {
                            selectedTemplate = template
                            isPresented = false
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("Choose a Template")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        isPresented = false
                    }
                }
            }
        }
    }
}
