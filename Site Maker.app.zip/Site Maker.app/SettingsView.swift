import SwiftUI

struct SettingsView: View {
    @ObservedObject var themeManager = ThemeManager.shared

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Themes")) {
                    Toggle("Rainbow Blend", isOn: $themeManager.isRainbowBlendEnabled)
                    List(themeManager.themes) { theme in
                        HStack {
                            Text(theme.name)
                            Spacer()
                            if themeManager.selectedThemeNames.contains(theme.name) && !themeManager.isRainbowBlendEnabled {
                                Image(systemName: "checkmark")
                            }
                        }
                        .onTapGesture {
                            if !themeManager.isRainbowBlendEnabled {
                                if let index = themeManager.selectedThemeNames.firstIndex(of: theme.name) {
                                    themeManager.selectedThemeNames.remove(at: index)
                                } else {
                                    themeManager.selectedThemeNames = [theme.name]
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("Settings")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        // Handle dismissal
                    }
                }
            }
        }
    }
}
