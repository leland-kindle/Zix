import SwiftUI

struct ContentView: View {
    @EnvironmentObject var themeManager: ThemeManager
    @EnvironmentObject var authenticationManager: AuthenticationManager
    @State private var showingSettings = false
    @State private var showingTemplateLibrary = false
    @State private var newWebsite: Website?

    var body: some View {
        NavigationView {
            VStack {
                Text("Site Maker")
                    .font(.largeTitle)
                    .padding(.bottom, 50)
                    .foregroundColor(themeManager.currentPrimaryColor)

                Button("Create New Website") {
                    showingTemplateLibrary = true
                }
                .padding()
                .buttonStyle(.borderedProminent)
                .tint(themeManager.currentPrimaryColor)
                .sheet(isPresented: $showingTemplateLibrary) {
                    TemplateLibraryView(isPresented: $showingTemplateLibrary, selectedTemplate: $newWebsite)
                }

                if let website = newWebsite {
                    NavigationLink(destination: EmailSetupView(isPresented: .constant(false), website: .constant(website)), isActive: Binding(
                        get: { newWebsite != nil },
                        set: { newValue in
                            if !newValue {
                                newWebsite = nil
                            }
                        }
                    )) {
                        EmptyView()
                    }
                    .hidden()
                    .onAppear {
                        // Navigate to email setup after template selection
                    }
                }
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showingSettings = true
                    } label: {
                        Image(systemName: "gear")
                            .foregroundColor(themeManager.currentPrimaryColor)
                    }
                    .sheet(isPresented: $showingSettings) {
                        SettingsView()
                    }
                }
            }
            .navigationTitle("Welcome")
        }
    }
}
