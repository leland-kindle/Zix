import SwiftUI
import WebKit

struct WebsiteCustomizerView: View {
    @Binding var website: Website
    @State private var showCodeEditor = false
    @State private var showAIAssistant = false

    var body: some View {
        VStack {
            WebView(htmlContent: $website.htmlContent)
                .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)

            HStack {
                Button("Visual Edit (Coming Soon)") {
                    // Implement visual editing UI
                }
                .padding()

                Button("Code Editor") {
                    showCodeEditor = true
                }
                .padding()

                Button("AI Assistant") {
                    showAIAssistant = true
                }
                .padding()

                Button("Publish") {
                    publishWebsite()
                }
                .padding()
                .buttonStyle(.borderedProminent)
            }
            .padding(.bottom)
        }
        .sheet(isPresented: $showCodeEditor) {
            CodeEditorView(code: $website.htmlContent)
        }
        .sheet(isPresented: $showAIAssistant) {
            AIAssistantView(websiteContent: $website.htmlContent)
        }
        .navigationTitle(website.name)
    }

    func publishWebsite() {
        print("Publishing website: \(website.name) with content: \(website.htmlContent)")
        PublishingManager.shared.publishWebsite(website: website) { result in
            switch result {
            case .success(let url):
                print("Website published at: \(url)")
                // Inform user of successful publishing
            case .failure(let error):
                print("Error publishing: \(error)")
                // Inform user of publishing error
            }
        }
    }
}

struct WebView: UIViewRepresentable {
    @Binding var htmlContent: String

    func makeUIView(context: Context) -> WKWebView {
        return WKWebView()
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        uiView.loadHTMLString(htmlContent, baseURL: nil)
    }
}
