import Foundation

class PublishingManager {
    static let shared = PublishingManager()
    private let backendService = BackendService.shared

    func publishWebsite(website: Website, completion: @escaping (Result<URL, Error>) -> Void) {
        print("Publishing website: \(website.name)")
        backendService.saveWebsite(website: website) { result in
            switch result {
            case .success(let websiteURL):
                print("Website published at: \(websiteURL)")
                completion(.success(websiteURL))
            case .failure(let error):
                print("Error publishing website: \(error)")
                completion(.failure(error))
            }
        }
    }
}
