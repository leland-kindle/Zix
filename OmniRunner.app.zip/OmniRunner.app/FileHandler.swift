import Foundation
import Compression

class FileHandler {
    static func compressFile(url: URL, completion: @escaping (URL?) -> Void) {
        do {
            let originalData = try Data(contentsOf: url)
            let compressedData = compress(data: originalData)
            let tempURL = FileManager.default.temporaryDirectory.appendingPathComponent(url.lastPathComponent + ".compressed")
            try compressedData.write(to: tempURL)
            completion(tempURL)
        } catch {
            print("Error compressing file: \(error)")
            completion(nil)
        }
    }

    static func decompressFile(url: URL) -> Data? {
        if let compressedData = try? Data(contentsOf: url) {
            return decompress(data: compressedData)
        }
        return nil
    }

    private static func compress(data: Data) -> Data {
        guard let buffer = UnsafeMutablePointer<UInt8>.allocate(capacity: data.count) else { return Data() }
        data.copyBytes(to: buffer, count: data.count)
        let compressedBuffer = UnsafeMutablePointer<UInt8>.allocate(capacity: data.count) // Start with max size
        var compressedSize = data.count

        let status = compression_encode_buffer(compressedBuffer, compressedSize, buffer, data.count, nil, COMPRESSION_LZMA)

        if status == COMPRESSION_STATUS_OK {
            return Data(bytes: compressedBuffer, count: compressedSize)
        } else {
            print("Compression failed with status: \(status)")
            return data // Return original if compression fails
        }
    }

    private static func decompress(data: Data) -> Data? {
        guard let buffer = UnsafeMutablePointer<UInt8>.allocate(capacity: data.count * 5) else { return nil } // Allocate a larger buffer
        data.copyBytes(to: buffer, count: data.count)
        let decompressedBuffer = UnsafeMutablePointer<UInt8>.allocate(capacity: data.count * 5)
        var decompressedSize = data.count * 5

        let status = compression_decode_buffer(decompressedBuffer, decompressedSize, buffer, data.count, nil, COMPRESSION_LZMA)

        if status == COMPRESSION_STATUS_OK {
            return Data(bytes: decompressedBuffer, count: decompressedSize)
        } else {
            print("Decompression failed with status: \(status)")
            return nil
        }
    }
}
