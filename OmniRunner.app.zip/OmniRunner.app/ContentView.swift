import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @EnvironmentObject var dependencyInstaller: DependencyInstaller
    @State private var selectedFileURL: URL?
    @State private var statusMessage: String = "OmniRunner"
    @State private var fileContent: String = ""
    @State private var installButtonVisible: Bool = false
    @State private var fullDiskAccessGranted: Bool = false

    var body: some View {
        VStack {
            Text("OmniRunner")
                .font(.largeTitle)
                .padding()

            if installButtonVisible {
                Button("Install Required Components") {
                    dependencyInstaller.installDependencies()
                }
                .padding()
                .foregroundColor(.white)
                .background(Color.red)
                .cornerRadius(10)
                .controlSize(.large)

                if !fullDiskAccessGranted {
                    Text("OmniRunner requires Full Disk Access to install necessary components.")
                        .font(.caption)
                        .foregroundColor(.gray)
                        .padding(.top, 5)
                    Button("Open System Settings for Full Disk Access") {
                        openSystemSettingsForFullDiskAccess()
                    }
                    .font(.caption)
                    .padding(.top, 2)
                }
            } else {
                HStack {
                    Button("Select File") { selectFile() }
                    Spacer()
                    Button("Create Code") { isCreatingCode = true }
                }
                .padding()

                if isCreatingCode {
                    VStack {
                        Picker("Language", selection: $selectedLanguage) {
                            Text("Python").tag("python")
                            Text("C++").tag("cpp")
                            // Add more languages as needed
                        }
                        TextEditor(text: $codeText)
                            .frame(height: 200)
                            .border(Color.gray)
                            .padding()
                        Button("Save & Run") { saveAndRunCode() }.padding()
                    }
                    .padding()
                }

                if let url = selectedFileURL {
                    Text("Selected File: \(url.lastPathComponent)")
                }

                Button("Run") { handleFile() }
                    .padding()
                    .disabled(selectedFileURL == nil && !isCreatingCode)

                ScrollView {
                    Text(outputLog)
                        .font(.system(size: 12, monospaced: true))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding()
                }
                .frame(height: 150)
                .border(Color.gray)
                .padding()
                Text(statusMessage).padding()
            }

            Spacer()
        }
        .onDrop(of: [UTType.fileURL], isTargeted: nil) { providers in
            if let provider = providers.first {
                provider.loadItem(forTypeIdentifier: UTType.fileURL.identifier) { (url, error) in
                    if let fileURL = url as? URL {
                        DispatchQueue.main.async {
                            selectedFileURL = fileURL
                            statusMessage = "File selected: \(fileURL.lastPathComponent)"
                            fileContent = ""
                        }
                    }
                }
                return true
            }
            return false
        }
        .onAppear {
            checkInstallationAndPermissions()
        }
    }

    @State private var isCreatingCode: Bool = false
    @State private var selectedLanguage: String = "python"
    @State private var codeText: String = ""
    @State private var outputLog: String = ""

    func checkInstallationAndPermissions() {
        // Simplified check - in a real app, you'd need a more robust method
        let dependenciesInstalled = (dependencyInstaller.installationStatus == .completed)
        // For now, we'll just assume Full Disk Access is needed.
        fullDiskAccessGranted = false // Replace with actual check if possible
        installButtonVisible = !dependenciesInstalled || !fullDiskAccessGranted
    }

    func openSystemSettingsForFullDiskAccess() {
        if let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_AllFiles") {
            NSWorkspace.shared.open(url)
        }
    }

    func selectFile() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = true
        panel.canChooseDirectories = false
        if panel.runModal() == .OK, let url = panel.url {
            selectedFileURL = url
            statusMessage = "File selected: \(url.lastPathComponent)"
            fileContent = ""
            isCreatingCode = false
        }
    }

    func saveAndRunCode() {
        let fileExtension = selectedLanguage == "python" ? "py" : (selectedLanguage == "cpp" ? "cpp" : "")
        let fileName = "MyCode.\(fileExtension)"
        let omniRunnerDir = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("OmniRunner")
        try? FileManager.default.createDirectory(at: omniRunnerDir, withIntermediateDirectories: true)
        let fileURL = omniRunnerDir.appendingPathComponent(fileName)

        do {
            try codeText.write(to: fileURL, atomically: true, encoding: .utf8)
            selectedFileURL = fileURL // Set as selected for running
            statusMessage = "Code saved to \(fileURL.path), running..."
            handleFile()
            isCreatingCode = false
        } catch {
            statusMessage = "Error saving code: \(error.localizedDescription)"
        }
    }

    func handleFile() {
        guard let url = selectedFileURL else {
            statusMessage = "No file selected to run."
            return
        }
        statusMessage = "Processing \(url.lastPathComponent)..."
        FileHandler.compressFile(url: url) { compressedURL in
            if let compressed = compressedURL {
                RunnerEngine.runFile(url: compressed) { result in
                    DispatchQueue.main.async {
                        outputLog = result
                        if result.starts(with: "Text Content:") {
                            fileContent = String(result.dropFirst("Text Content:".count).trimmingCharacters(in: .whitespacesAndNewlines))
                        }
                        statusMessage = "Ready"
                    }
                }
            } else {
                DispatchQueue.main.async {
                    statusMessage = "Compression failed."
                }
            }
        }
    }
}
