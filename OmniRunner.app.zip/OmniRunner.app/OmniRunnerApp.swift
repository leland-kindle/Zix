import SwiftUI

@main
struct OmniRunnerApp: App {
    @StateObject var dependencyInstaller = DependencyInstaller()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(dependencyInstaller)
                .onAppear {
                    dependencyInstaller.checkInstallationStatus()
                }
        }
    }
}
