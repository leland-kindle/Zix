import Foundation

class RunnerEngine {
    static func runFile(url: URL, completion: @escaping (String) -> Void) {
        let fileExtension = url.pathExtension.lowercased()
        let decompressedData = FileHandler.decompressFile(url: url)

        guard let decompressedFileURL = createTemporaryFile(withData: decompressedData, originalName: url.deletingPathExtension().lastPathComponent, extension: fileExtension) else {
            completion("Error creating temporary file for execution.")
            return
        }

        if fileExtension == "exe" {
            runWine(filePath: decompressedFileURL.path, completion: completion)
        } else if fileExtension == "py" {
            runPython(filePath: decompressedFileURL.path, completion: completion)
        } else if fileExtension == "cpp" {
            compileAndRunCPP(filePath: decompressedFileURL.path, completion: completion)
        } else if fileExtension == "txt" {
            if let data = decompressedData, let text = String(data: data, encoding: .utf8) {
                completion("Text Content: \(text)")
            } else {
                completion("Could not read text file.")
            }
        } else if fileExtension == "app" {
            runMacOSApp(filePath: decompressedFileURL.path, completion: completion)
        } else {
            completion("Unsupported file type: \(fileExtension)")
        }
    }

    private static func createTemporaryFile(withData data: Data?, originalName: String, extension: String) -> URL? {
        guard let data = data else { return nil }
        let tempDir = FileManager.default.temporaryDirectory
        let tempURL = tempDir.appendingPathComponent("\(originalName).\(extension)")
        try? data.write(to: tempURL)
        return tempURL
    }

    private static func runWine(filePath: String, completion: @escaping (String) -> Void) {
        runShellCommand(command: "wine \"\(filePath)\"") { success, output, error in
            completion("Wine Output: \(output ?? "") Error: \(error?.localizedDescription ?? "")")
        }
    }

    private static func runPython(filePath: String, completion: @escaping (String) -> Void) {
        runShellCommand(command: "python3 \"\(filePath)\"") { success, output, error in
            completion("Python Output: \(output ?? "") Error: \(error?.localizedDescription ?? "")")
        }
    }

    private static func compileAndRunCPP(filePath: String, completion: @escaping (String) -> Void) {
        let executablePath = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).path
        runShellCommand(command: "g++ \"\(filePath)\" -o \"\(executablePath)\"") { compileSuccess, compileOutput, compileError in
            if compileSuccess {
                runShellCommand(command: "\"\(executablePath)\"") { runSuccess, runOutput, runError in
                    completion("C++ Output: \(runOutput ?? "") Compile Error: \(compileError?.localizedDescription ?? "") Run Error: \(runError?.localizedDescription ?? "")")
                }
            } else {
                completion("C++ Compilation Failed: \(compileOutput ?? "") Error: \(compileError?.localizedDescription ?? "")")
            }
        }
    }

    private static func runMacOSApp(filePath: String, completion: @escaping (String) -> Void) {
        let pathURL = URL(fileURLWithPath: filePath)
        NSWorkspace.shared.open(path
