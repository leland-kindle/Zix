import Foundation

enum InstallationStatus {
    case notStarted, pending, completed, failed
}

class DependencyInstaller: ObservableObject {
    @Published var installationStatus: InstallationStatus = .notStarted
    let requiredTools = ["wine", "brew", "python3", "g++"]

    func checkInstallationStatus() {
        if installationStatus == .notStarted {
            // Perform a quick check to see if essential tools might be present
            if isToolInstalled("brew") && isToolInstalled("python3") {
                installationStatus = .completed // Assume installed for simplicity
            } else {
                installationStatus = .pending // Show install button
            }
        }
    }

    func installDependencies() {
        guard installationStatus != .pending && installationStatus != .completed else { return }
        installationStatus = .pending

        checkAndInstallHomebrew { homebrewInstalled in
            if homebrewInstalled {
                self.installRemainingTools()
            } else {
                DispatchQueue.main.async {
                    self.installationStatus = .failed
                }
            }
        }
    }

    private func checkAndInstallHomebrew(completion: @escaping (Bool) -> Void) {
        if !isToolInstalled("brew") {
            print("Installing Homebrew...")
            runShellCommand(command: "/bin/bash -c \"$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\"") { success, output, error in
                DispatchQueue.main.async {
                    if success {
                        print("Homebrew installed successfully.")
                        completion(true)
                    } else {
                        print("Error installing Homebrew: \(output ?? "") \(error?.localizedDescription ?? "")")
                        self.installationStatus = .failed
                        completion(false)
                    }
                }
            }
        } else {
            print("Homebrew is already installed.")
            completion(true)
        }
    }

    private func installRemainingTools() {
        for tool in requiredTools {
            if !isToolInstalled(tool) {
                print("Installing \(tool) using Homebrew...")
                runShellCommand(command: "brew install \(tool)") { success, output, error in
                    DispatchQueue.main.async {
                        if success {
                            print("\(tool) installed successfully.")
                        } else {
                            print("Error installing \(tool): \(output ?? "") \(error?.localizedDescription ?? "")")
                            self.installationStatus = .failed
                        }
                    }
                }
            } else {
                print("\(tool) is already installed.")
            }
        }
        DispatchQueue.main.async {
            self.installationStatus = .completed
        }
    }

    private func isToolInstalled(_ toolName: String) -> Bool {
        let task = Process()
        task.executableURL = URL(fileURLWithPath: "/usr/bin/env")
        task.arguments = ["which", toolName]
        let pipe = Pipe()
        task.standardOutput = pipe
        do {
            try task.run()
            task.waitUntilExit()
            let data = try pipe.fileHandleForReading.readToEnd()
            if let output = String(data: data ?? Data(), encoding: .utf8), !output.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                return true
            }
        } catch {
            print("Error checking for \(toolName): \(error)")
        }
        return false
    }

    private func runShellCommand(command: String, completion: @escaping (Bool, String?, Error?) -> Void) {
        let task = Process()
        task.executableURL = URL(fileURLWithPath: "/bin/bash")
        task.arguments = ["-c", command]
        let outputPipe = Pipe()
        let errorPipe = Pipe()
        task.standardOutput = outputPipe
        task.standardError = errorPipe

        do {
            try task.run()
            task.waitUntilExit()

            let outputData = try outputPipe.fileHandleForReading.readToEnd()
            let errorData = try errorPipe.fileHandleForReading.readToEnd()
            let output = String(decoding: outputData ?? Data(), as: UTF8.self)
            let error = String(decoding: errorData ?? Data(), as: UTF8.self)

            completion(task.terminationStatus == 0, output, error.isEmpty ? nil : NSError(domain: "ShellCommandError", code: Int(task.terminationStatus), userInfo: [NSLocalizedDescriptionKey: error]))

        } catch {
            completion(false, nil, error)
        }
    }
}
