import SwiftUI
import GoogleSignIn

@main
struct OpenPuzzlesApp: App {
    @StateObject var googleSignInManager = GoogleSignInManager()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(googleSignInManager)
        }
    }
}
