import SwiftUI
import GoogleSignIn

struct ContentView: View {
    @EnvironmentObject var googleSignInManager: GoogleSignInManager
    @State private var showingPuzzleList = false

    var body: some View {
        NavigationView {
            VStack {
                Text("Open Puzzles")
                    .font(.largeTitle)
                    .padding(.bottom, 50)

                if googleSignInManager.currentUser != nil {
                    Text("Signed in as: \(googleSignInManager.currentUser?.profile?.name ?? "User")")
                        .padding(.bottom, 20)

                    Button("View My Puzzles") {
                        showingPuzzleList = true
                    }
                    .padding()
                    .buttonStyle(.borderedProminent)

                    Button("Sign Out") {
                        googleSignInManager.signOut()
                    }
                    .padding()
                    .foregroundColor(.red)
                } else {
                    Button("Sign in with Google") {
                        googleSignInManager.signIn()
                    }
                    .padding()
                    .buttonStyle(.borderedProminent)
                }
            }
            .navigationTitle("Open Puzzles")
            .fullScreenCover(isPresented: $showingPuzzleList) {
                PuzzleListView()
            }
        }
    }
}
