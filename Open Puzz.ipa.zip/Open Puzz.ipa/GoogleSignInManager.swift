import GoogleSignIn
import SwiftUI

class GoogleSignInManager: NSObject, ObservableObject, GIDSignInDelegate {
    @Published var currentUser: GIDGoogleUser?
    @Published var isSignedIn: Bool = false

    override init() {
        super.init()
        GIDSignIn.sharedInstance().delegate = self
        GIDSignIn.sharedInstance().restorePreviousSignIn()
    }

    func signIn() {
        guard let presentingViewController = (UIApplication.shared.connectedScenes.first as? UIWindowScene)?.windows.first?.rootViewController else { return }
        GIDSignIn.sharedInstance().signIn(with: GIDSignInConfig(), presenting: presentingViewController) { user, error in
            if let error = error {
                print("Google Sign-in Error: \(error.localizedDescription)")
                self.currentUser = nil
                self.isSignedIn = false
                return
            }
            self.currentUser = user
            self.isSignedIn = true
            user?.authentication.do { authentication, error in
                if let error = error {
                    print("Error getting Google Auth Token: \(error.localizedDescription)")
                    return
                }
                guard let token = authentication?.idToken else { return }
                print("Google ID Token: \(token)")
                // You can now use this token to authenticate with your backend or Google Cloud
            }
        }
    }

    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        // Deprecated in newer SDKs, the block in signIn() is preferred.
        // Keeping it for potential compatibility if needed.
        if let error = error {
            print("Google Sign-in Error (delegate): \(error.localizedDescription)")
            currentUser = nil
            isSignedIn = false
            return
        }
        currentUser = user
        isSignedIn = true
        user.authentication.do { authentication, error in
            if let error = error {
                print("Error getting Google Auth Token (delegate): \(error.localizedDescription)")
                return
            }
            guard let token = authentication?.idToken else { return }
            print("Google ID Token (delegate): \(token)")
        }
    }

    func signOut() {
        GIDSignIn.sharedInstance().signOut()
        currentUser = nil
        isSignedIn = false
    }
}
