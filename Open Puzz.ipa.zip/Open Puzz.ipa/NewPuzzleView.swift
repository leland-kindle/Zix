import SwiftUI
import PhotosUI

struct NewPuzzleView: View {
    @Environment(\.dismiss) var dismiss
    @State private var puzzleName: String = ""
    @State private var completedImage: UIImage?
    @State private var boxImage: UIImage?
    @State private var frameImage: UIImage?
    @State private var maker: String = ""
    @State private var purchaseLocation: String = ""
    @State private var showingImagePicker: Bool = false
    @State private var selectedImageType: ImageType?
    @State private var isProcessing: Bool = false
    @State private var generatedPuzzle: Puzzle?
    var onPuzzleCreated: (Puzzle) -> Void

    enum ImageType {
        case completed, box, frame
    }

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Puzzle Details")) {
                    TextField("Puzzle Name", text: $puzzleName)
                    TextField("Maker (Optional)", text: $maker)
                    TextField("Purchase Location (Optional)", text: $purchaseLocation)
                }

                Section(header: Text("Upload Images")) {
                    HStack {
                        Text("Completed Puzzle")
                        Spacer()
                        if let completedImage = completedImage {
                            Image(uiImage: completedImage)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 50, height: 50)
                        }
                        Button("Upload") {
                            selectedImageType = .completed
                            showingImagePicker = true
                        }
                    }
                    HStack {
                        Text("Puzzle Box (Optional)")
                        Spacer()
                        if let boxImage = boxImage {
                            Image(uiImage: boxImage)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 50, height: 50)
                        }
                        Button("Upload") {
                            selectedImageType = .box
                            showingImagePicker = true
                        }
                    }
                    HStack {
                        Text("Empty Puzzle Frame")
                        Spacer()
                        if let frameImage = frameImage {
                            Image(uiImage: frameImage)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 50, height: 50)
                        }
                        Button("Upload") {
                            selectedImageType = .frame
                            showingImagePicker = true
                        }
                    }
                }

                Button("Create Puzzle") {
                    createOpenPuzzle()
                }
                .disabled(puzzleName.isEmpty || completedImage == nil || frameImage == nil || isProcessing)

                if isProcessing {
                    ProgressView("Processing...")
                }

                if let generatedPuzzle = generatedPuzzle {
                    NavigationLink(destination: PuzzleDetailView(puzzle: generatedPuzzle), isActive: Binding(
                        get: { self.generatedPuzzle != nil },
                        set: { newValue in
                            if !newValue {
                                self.generatedPuzzle = nil
                            }
                        }
                    )) {
                        EmptyView()
                    }
                    .hidden()
                }
            }
            .navigationTitle("New Puzzle")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
            .sheet(isPresented: $showingImagePicker, onDismiss: { selectedImageType = nil }) {
                ImagePicker(image: binding(for: selectedImageType))
            }
        }
    }

    private func binding(for imageType: ImageType?) -> Binding<UIImage?> {
        switch imageType {
        case .completed:
            return $completedImage
        case .box:
            return $boxImage
        case .frame:
            return $frameImage
        case .none:
            return .constant(nil)
        }
    }

    func createOpenPuzzle() {
        guard let completedData = completedImage?.jpegData(compressionQuality: 0.8),
              let frameData = frameImage?.jpegData(compressionQuality: 0.8) else {
            statusMessage("Error: Could not convert images to data.")
            return
        }

        isProcessing = true
        statusMessage("Processing puzzle...")

        Task {
            do {
                let aiManager = AIManager()
                guard let solvedImage = try await aiManager.generateSolvedPuzzleImage(puzzleDescription: puzzleName, frameImage: frameData) else {
                    DispatchQueue.main.async {
                        statusMessage("Error: Could not generate solved puzzle image.")
                        isProcessing = false
                    }
                    return
                }

                let solutionSteps = SolutionGenerator.generateSolutionSteps(solvedPuzzleImage: solvedImage)

                // Placeholder for video generation
                VideoGenerator.generatePlacementVideo(puzzle: Puzzle(name: puzzleName, completedImage: completedData, boxImage: boxImage?.jpegData(compressionQuality: 0.8), frameImage: frameData, solutionSteps: solutionSteps, maker: maker, purchaseLocation: purchaseLocation), solutionSteps: solutionSteps) { videoURL in
                    let newPuzzle = Puzzle(name: puzzleName, completedImage: completedData, boxImage: boxImage?.jpegData(compressionQuality: 0.8), frameImage: frameData, solutionSteps: solutionSteps, videoURL: videoURL, maker: maker, purchaseLocation: purchaseLocation)
                    DispatchQueue.main.async {
                        onPuzzleCreated(newPuzzle)
                        generatedPuzzle = newPuzzle
                        isProcessing = false
                        statusMessage("Puzzle created!")
                    }
                }

            } catch {
                DispatchQueue.main.async {
                    statusMessage("Error during AI processing: \(error.localizedDescription)")
                    isProcessing = false
                }
            }
        }
    }

    @State private var processingStatus: String = ""
    func statusMessage(_ message: String) {
        print(message)
        processingStatus = message
    }
}

struct ImagePicker: UIViewControllerRepresentable {
    @Binding var image: UIImage?
    @Environment(\.dismiss) var dismiss

    func makeUIViewController(context: UIViewControllerRepresentableContext<ImagePicker>) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: UIViewControllerRepresentableContext<ImagePicker>) {

    }

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent: ImagePicker

        init(_ parent: ImagePicker) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let uiImage = info[.originalImage] as? UIImage {
                parent.image = uiImage
            }

            parent.dismiss()
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.dismiss()
        }
    }
}
