import SwiftUI
import AVKit

struct PuzzleDetailView: View {
    let puzzle: Puzzle

    var body: some View {
        ScrollView {
            VStack(alignment: .leading) {
                Text(puzzle.name)
                    .font(.title)
                    .padding(.bottom)

                if let completedImageData = puzzle.completedImage, let image = UIImage(data: completedImageData) {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .cornerRadius(8)
                        .shadow(radius: 4)
                        .padding(.bottom)
                } else {
                    Text("Completed image not available.")
                        .foregroundColor(.gray)
                        .padding(.bottom)
                }

                if !puzzle.solutionSteps.isEmpty {
                    Text("Solution Steps:")
                        .font(.headline)
                        .padding(.bottom, 5)
                    ForEach(puzzle.solutionSteps) { step in
                        HStack {
                            if let pieceImageData = step.pieceImage, let pieceImage = UIImage(data: pieceImageData) {
                                Image(uiImage: pieceImage)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 40, height: 40)
                                    .padding(.trailing, 5)
                            }
                            Text(step.placementHint)
                        }
                        .padding(.bottom, 2)
                    }
                    .padding(.bottom)
                } else {
                    Text("Solution steps are being generated...")
                        .foregroundColor(.gray)
                        .padding(.bottom)
                }

                if let videoURL = puzzle.videoURL {
                    Text("Placement Video:")
                        .font(.headline)
                        .padding(.bottom, 5)
                    VideoPlayer(player: AVPlayer(url: videoURL))
                        .frame(height: 300)
                        .cornerRadius(8)
                        .shadow(radius: 4)
                } else {
                    Text("Placement video is being generated...")
                        .foregroundColor(.gray)
                }
            }
            .padding()
        }
        .navigationTitle(puzzle.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}
