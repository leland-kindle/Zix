import SwiftUI
import UniformTypeIdentifiers

struct NewVMView: View {
    @ObservedObject var vmManager: VMManager
    @Environment(\.dismiss) var dismiss
    @State private var vmName: String = ""
    @State private var operatingSystem: String = ""
    @State private var cpuCores: Int = 2
    @State private var memoryGB: Int = 2
    @State private var bootISOURL: URL?

    var body: some View {
        NavigationView {
            Form {
                TextField("Virtual Machine Name", text: $vmName)
                TextField("Operating System", text: $operatingSystem)
                Stepper("CPU Cores: \(cpuCores)", value: $cpuCores, in: 1...ProcessInfo.processInfo.processorCount)
                Stepper("Memory (GB): \(memoryGB)", value: $memoryGB, in: 1...32) // Adjust range as needed

                Button("Select Boot ISO") {
                    selectBootISO()
                }
                if let url = bootISOURL {
                    Text("Selected: \(url.lastPathComponent)")
                }
            }
            .navigationTitle("New Virtual Machine")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Create") {
                        let newVM = VirtualMachine(name: vmName, operatingSystem: operatingSystem, cpuCores: cpuCores, memoryGB: memoryGB, bootISOPath: bootISOURL?.path)
                        vmManager.addVM(newVM)
                        dismiss()
                    }
                    .disabled(vmName.isEmpty || operatingSystem.isEmpty || bootISOURL == nil)
                }
            }
            .padding()
        }
    }

    func selectBootISO() {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [UTType.iso9660, UTType.diskImage]
        panel.canChooseFiles = true
        panel.canChooseDirectories = false
        panel.allowsMultipleSelection = false
        if panel.runModal() == .OK {
            bootISOURL = panel.urls.first
        }
    }
}
