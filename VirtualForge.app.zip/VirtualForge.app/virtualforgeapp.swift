import SwiftUI

@main
struct VirtualForgeApp: App {
    var body: some Scene {
        WindowGroup {
            VMListView() // Start with a list of virtual machines
        }
    }
}
