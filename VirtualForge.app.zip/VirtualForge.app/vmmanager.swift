import Foundation

class VMManager: ObservableObject {
    @Published var virtualMachines: [VirtualMachine] = []

    init() {
        // Load VMs from storage (e.g., UserDefaults or a file)
        loadVMs()
    }

    func addVM(_ vm: VirtualMachine) {
        virtualMachines.append(vm)
        saveVMs()
    }

    func deleteVM(at offsets: IndexSet) {
        virtualMachines.remove(atOffsets: offsets)
        saveVMs()
    }

    func saveVMs() {
        // Implement saving VMs to storage
        print("VMs saved")
    }

    func loadVMs() {
        // Implement loading VMs from storage
        print("VMs loaded")
        // For now, add a default VM for testing
        let defaultVM = VirtualMachine(name: "Test VM", operatingSystem: "Linux", cpuCores: 4, memoryGB: 8, bootISOPath: "/path/to/your/iso.iso")
        virtualMachines.append(defaultVM)
    }
}
