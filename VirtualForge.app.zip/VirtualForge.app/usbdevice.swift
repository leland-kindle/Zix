import Foundation
import IOKit.IOKit

struct USBDevice: Identifiable {
    let id = UUID()
    let identifier: String // Unique identifier from IOKit
    let vendorID: Int
    let productID: Int
    let productName: String?
    // ... other relevant USB device properties

    init?(ioObject: io_object_t) {
        let service = ioObject
        guard let vendorID = IORegistryEntryGetProperty(service, kUSBVendorID as CFString)?.takeUnretainedValue() as? Int,
              let productID = IORegistryEntryGetProperty(service, kUSBProductID as CFString)?.takeUnretainedValue() as? Int,
              let productName = IORegistryEntryGetProperty(service, kUSBProductName as CFString)?.takeUnretainedValue() as? String else {
            return nil
        }

        self.identifier = String(format: "%04x:%04x", vendorID, productID) // Simple identifier
        self.vendorID = vendorID
        self.productID = productID
        self.productName = productName
    }
}

class USBDeviceManager: ObservableObject {
    @Published var connectedDevices: [USBDevice] = []

    init() {
        refreshConnectedDevices()
    }

    func refreshConnectedDevices() {
        connectedDevices.removeAll()

        let matchingDict = IOServiceMatching(kIOUSBDeviceClassName)
        var iterator: io_iterator_t = 0
        let kernResult = IOServiceGetMatchingServices(kIOMasterPortDefault, matchingDict, &iterator)

        if kernResult == KERN_SUCCESS {
            while case let usbDevice = IOIteratorNext(iterator), usbDevice != 0 {
                if let device = USBDevice(ioObject: usbDevice) {
                    connectedDevices.append(device)
                }
                IOObjectRelease(usbDevice)
            }
        }
        IOObjectRelease(iterator)
    }
}
