import SwiftUI

struct VMDetailsView: View {
    @ObservedObject var vm: VirtualMachine

    var body: some View {
        VStack {
            Text(vm.name)
                .font(.title)
                .padding()

            Form {
                LabeledContent("Operating System") {
                    Text(vm.operatingSystem)
                }
                LabeledContent("CPU Cores") {
                    Text("\(vm.cpuCores)")
                }
                LabeledContent("Memory (GB)") {
                    Text("\(vm.memoryGB)")
                }
                LabeledContent("Boot ISO") {
                    Text(vm.bootISOPath ?? "None")
                }
                // ... other configuration details

                Section("USB Devices") {
                    List {
                        ForEach(vm.usbDevices, id: \.identifier) { usbDevice in
                            Text(usbDevice.productName ?? "Unknown USB Device")
                        }
                    }
                    Button("Add USB Device") {
                        // Logic to select and add a USB device for passthrough
                    }
                }
            }
            .padding()

            HStack {
                Button("Start") {
                    vm.start() // Placeholder
                }
                Button("Stop") {
                    vm.stop() // Placeholder
                }
                Button("Edit") {
                    // Present VM editing view
                }
            }
            .padding()
        }
        .navigationTitle(vm.name)
    }
}
