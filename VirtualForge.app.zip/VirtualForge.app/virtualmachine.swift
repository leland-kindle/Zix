import Foundation

class VirtualMachine: Identifiable, ObservableObject {
    let id = UUID()
    @Published var name: String
    @Published var operatingSystem: String
    @Published var cpuCores: Int
    @Published var memoryGB: Int
    @Published var bootISOPath: String?
    @Published var usbDevices: [USBDevice] = [] // For USB passthrough

    init(name: String, operatingSystem: String, cpuCores: Int, memoryGB: Int, bootISOPath: String? = nil) {
        self.name = name
        self.operatingSystem = operatingSystem
        self.cpuCores = cpuCores
        self.memoryGB = memoryGB
        self.bootISOPath = bootISOPath
    }

    func start() {
        print("Starting VM: \(name)")
        // Logic to start the VM using Virtualization framework or QEMU
    }

    func stop() {
        print("Stopping VM: \(name)")
        // Logic to stop the VM
    }

    // Method to add USB device for passthrough
    func addUSBDevice(device: USBDevice) {
        if !usbDevices.contains(where: { $0.identifier == device.identifier }) {
            usbDevices.append(device)
            print("Added USB device '\(device.productName ?? "Unknown")' to VM '\(name)'")
            // Logic to configure USB passthrough for the VM
        }
    }

    // Method to remove USB device
    func removeUSBDevice(device: USBDevice) {
        usbDevices.removeAll { $0.identifier == device.identifier }
        print("Removed USB device '\(device.productName ?? "Unknown")' from VM '\(name)'")
        // Logic to disable USB passthrough
    }
}
