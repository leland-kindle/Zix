import SwiftUI

struct VMListView: View {
    @StateObject var vmManager = VMManager()
    @State private var isPresentingNewVMSheet = false

    var body: some View {
        NavigationView {
            List {
                ForEach(vmManager.virtualMachines) { vm in
                    NavigationLink(destination: VMDetailsView(vm: vm)) {
                        Text(vm.name)
                    }
                }
                .onDelete(perform: vmManager.deleteVM)
            }
            .navigationTitle("VirtualForge")
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button(action: {
                        isPresentingNewVMSheet = true
                    }) {
                        Image(systemName: "plus")
                    }
                }
            }
            .sheet(isPresented: $isPresentingNewVMSheet) {
                NewVMView(vmManager: vmManager)
            }
            Text("Select a Virtual Machine") // Placeholder for detail view
        }
    }
}
