import Foundation

struct Puzzle: Identifiable {
    let id = UUID()
    var name: String
    var completedImage: Data?
    var boxImage: Data?
    var frameImage: Data?
    var solutionSteps: [SolutionStep] = []
    var videoURL: URL? // URL to the generated Canva video
    var maker: String?
    var purchaseLocation: String?
    // Add other relevant properties
}

struct SolutionStep: Identifiable {
    let id = UUID()
    let pieceImage: Data // Image of the individual piece
    let placementHint: String // Description of where it goes
}
