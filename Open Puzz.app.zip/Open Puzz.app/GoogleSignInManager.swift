import GoogleSignIn

class GoogleSignInManager: NSObject, ObservableObject, GIDSignInDelegate {
    @Published var currentUser: GIDGoogleUser?

    override init() {
        super.init()
        GIDSignIn.sharedInstance().delegate = self
        GIDSignIn.sharedInstance().restorePreviousSignIn()
    }

    func signIn() {
        guard let presentingViewController = (UIApplication.shared.connectedScenes.first as? UIWindowScene)?.windows.first?.rootViewController else { return }
        GIDSignIn.sharedInstance().signIn(with: SignInConfig(), presenting: presentingViewController)
    }

    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if let error = error {
            print("Google Sign-in Error: \(error.localizedDescription)")
            currentUser = nil
            return
        }
        currentUser = user
        user.authentication.do { authentication, error in
            if let error = error {
                print("Error getting Google Auth Token: \(error.localizedDescription)")
                return
            }
            guard let token = authentication?.idToken else { return }
            print("Google ID Token: \(token)")
            // You can now use this token to authenticate with your backend or Google Cloud
        }
    }

    func signOut() {
        GIDSignIn.sharedInstance().signOut()
        currentUser = nil
    }
}
